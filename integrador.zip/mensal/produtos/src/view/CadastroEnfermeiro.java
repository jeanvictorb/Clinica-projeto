package view;
import controller.EnfermeiroController;
import model.Enfermeiro;
import view.Home;

public class CadastroEnfermeiro extends javax.swing.JFrame {
    
    public CadastroEnfermeiro() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        voltar = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        cadastrar_enfermeiro = new javax.swing.JButton();
        celular_enfermeiro = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        telefone_enfermeiro = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        email_enfermeiro = new javax.swing.JTextField();
        rg_enfermeiro = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        enfermeiro_corem = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        nome_enfermeiro = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        cpf_enfermeiro = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        voltar.setBackground(new java.awt.Color(102, 255, 102));
        voltar.setText("voltar");
        voltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voltarActionPerformed(evt);
            }
        });

        jLabel8.setText("Telefone Celular");

        cadastrar_enfermeiro.setBackground(new java.awt.Color(102, 255, 102));
        cadastrar_enfermeiro.setText("Cadastrar");
        cadastrar_enfermeiro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadastrar_enfermeiroActionPerformed(evt);
            }
        });

        celular_enfermeiro.setBackground(new java.awt.Color(204, 255, 204));
        celular_enfermeiro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                celular_enfermeiroActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(153, 255, 153));

        jLabel1.setBackground(new java.awt.Color(153, 255, 153));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("Cadastro de Enfermeiro");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 571, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(68, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addContainerGap())
        );

        telefone_enfermeiro.setBackground(new java.awt.Color(204, 255, 204));

        jLabel9.setText("Email");

        email_enfermeiro.setBackground(new java.awt.Color(204, 255, 204));

        rg_enfermeiro.setBackground(new java.awt.Color(204, 255, 204));

        jLabel5.setText("corem");

        enfermeiro_corem.setBackground(new java.awt.Color(204, 255, 204));
        enfermeiro_corem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                enfermeiro_coremActionPerformed(evt);
            }
        });

        jLabel7.setText("Telefone Fixo");

        nome_enfermeiro.setBackground(new java.awt.Color(204, 255, 204));
        nome_enfermeiro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nome_enfermeiroActionPerformed(evt);
            }
        });

        jLabel2.setText("Nome do Enfermeiro");

        jLabel3.setText("CPF");

        cpf_enfermeiro.setBackground(new java.awt.Color(204, 255, 204));

        jLabel4.setText("RG");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel5)
                    .addComponent(jLabel2)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(nome_enfermeiro, javax.swing.GroupLayout.PREFERRED_SIZE, 556, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel3)
                                .addComponent(cpf_enfermeiro, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(18, 18, 18)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(rg_enfermeiro, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel4)
                                .addComponent(jLabel9))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(enfermeiro_corem)
                            .addComponent(jLabel7)
                            .addComponent(telefone_enfermeiro, javax.swing.GroupLayout.DEFAULT_SIZE, 269, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(celular_enfermeiro)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8)
                                    .addComponent(email_enfermeiro, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addGap(0, 12, Short.MAX_VALUE))
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(voltar, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(cadastrar_enfermeiro, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(76, 76, 76))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(nome_enfermeiro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cpf_enfermeiro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rg_enfermeiro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel9))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(enfermeiro_corem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(email_enfermeiro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(celular_enfermeiro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(telefone_enfermeiro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(86, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(voltar, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cadastrar_enfermeiro, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void celular_enfermeiroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_celular_enfermeiroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_celular_enfermeiroActionPerformed

    private void cadastrar_enfermeiroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadastrar_enfermeiroActionPerformed
    System.out.println("Boatao");     
        
    String nome = nome_enfermeiro.getText();
    String cpf = cpf_enfermeiro.getText();
    String rg = rg_enfermeiro.getText();
    String corem = enfermeiro_corem.getText();
    String celular = celular_enfermeiro.getText();
    String telefone = telefone_enfermeiro.getText();
    String email = email_enfermeiro.getText();
    
    Enfermeiro enfermeiro = new Enfermeiro(nome, cpf, rg, corem, celular, telefone, email);
    EnfermeiroController ClasseEnfermeiro = new EnfermeiroController();
    ClasseEnfermeiro.adicionarEnfermeiro(enfermeiro);
    
    nome_enfermeiro.setText("");
    cpf_enfermeiro.setText("");
    rg_enfermeiro.setText("");
    enfermeiro_corem.setText("");
    celular_enfermeiro.setText("");
    telefone_enfermeiro.setText("");
    email_enfermeiro.setText("");
    
    }//GEN-LAST:event_cadastrar_enfermeiroActionPerformed

    private void nome_enfermeiroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nome_enfermeiroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nome_enfermeiroActionPerformed

    private void voltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voltarActionPerformed
        Home view = new Home();
        view.setVisible(true);
        this.dispose();   
    }//GEN-LAST:event_voltarActionPerformed

    private void enfermeiro_coremActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_enfermeiro_coremActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_enfermeiro_coremActionPerformed

    public void abrirTelaInicial(){
    Home view = new Home();
    CadastroEnfermeiro enfermeiroView = new CadastroEnfermeiro();
     //view.setVisible(true);
            view.setVisible(true);
            this.dispose();
    }
            
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CadastroEnfermeiro().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cadastrar_enfermeiro;
    private javax.swing.JTextField celular_enfermeiro;
    private javax.swing.JTextField cpf_enfermeiro;
    private javax.swing.JTextField email_enfermeiro;
    private javax.swing.JTextField enfermeiro_corem;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField nome_enfermeiro;
    private javax.swing.JTextField rg_enfermeiro;
    private javax.swing.JTextField telefone_enfermeiro;
    private javax.swing.JButton voltar;
    // End of variables declaration//GEN-END:variables
}
