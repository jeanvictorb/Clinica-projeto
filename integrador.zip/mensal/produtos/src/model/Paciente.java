package model;

public class Paciente {
    
    private int id;
    private String nome;
    private String cpf;
    private String rg;
    private String numero_sus;
    private String data_nascimento;
    private String telefone;
    private String celular;
    private String email;
    private String sexo;
    private String CEP;
    private String estado;
    private String cidade;
    private String bairro;
    private String rua;
    private String numero;
    private String data_entrada;
    
        public Paciente() {
    }

    public Paciente(String nome, String cpf, String rg, String numero_sus, String data_nascimento, String telefone, String celular, String email, String sexo, String CEP, String estado, String cidade, String bairro, String rua, String numero, String data_entrada) {
        this.nome = nome;
        this.cpf = cpf;
        this.rg = rg;
        this.numero_sus = numero_sus;
        this.data_nascimento = data_nascimento;
        this.telefone = telefone;
        this.celular = celular;
        this.email = email;
        this.sexo = sexo;
        this.CEP = CEP;
        this.estado = estado;
        this.cidade = cidade;
        this.bairro = bairro;
        this.rua = rua;
        this.numero = numero;
        this.data_entrada = data_entrada;
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getCpf() {
        return cpf;
    }

    public String getRg() {
        return rg;
    }

    public String getNumero_sus() {
        return numero_sus;
    }

    public String getData_nascimento() {
        return data_nascimento;
    }

    public String getTelefone() {
        return telefone;
    }

    public String getCelular() {
        return celular;
    }

    public String getEmail() {
        return email;
    }

    public String getSexo() {
        return sexo;
    }

    public String getCEP() {
        return CEP;
    }

    public String getEstado() {
        return estado;
    }

    public String getCidade() {
        return cidade;
    }

    public String getBairro() {
        return bairro;
    }

    public String getRua() {
        return rua;
    }

    public String getNumero() {
        return numero;
    }

    public String getData_entrada() {
        return data_entrada;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public void setNumero_sus(String numero_sus) {
        this.numero_sus = numero_sus;
    }

    public void setData_nascimento(String data_nascimento) {
        this.data_nascimento = data_nascimento;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public void setCEP(String CEP) {
        this.CEP = CEP;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public void setData_entrada(String data_entrada) {
        this.data_entrada = data_entrada;
    }

    }
