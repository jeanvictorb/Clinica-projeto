
package model;

public class Medico {
  
    private int id;
    private String nome;
    private String cpf;
    private String rg;
    private String crm;
    private String telefone;
    private String celular;
    private String email;
    private String especialidade;

    public Medico() {
    }
    
    public Medico(String nome, String cpf, String rg, String crm, String telefone, String celular, String email, String especialidade) {
        this.nome = nome;
        this.cpf = cpf;
        this.rg = rg;
        this.crm = crm;
        this.telefone = telefone;
        this.celular = celular;
        this.email = email;
        this.especialidade = especialidade;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public String getRg() {
        return rg;
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getCpf() {
        return cpf;
    }

    public String getCrm() {
        return crm;
    }

    public String getTelefone() {
        return telefone;
    }

    public String getCelular() {
        return celular;
    }

    public String getEmail() {
        return email;
    }

    public String getEspecialidade() {
        return especialidade;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public void setCrm(String crm) {
        this.crm = crm;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    
}
