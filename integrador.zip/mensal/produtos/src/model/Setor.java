package model;

public class Setor {
    private int id;
    private String nome_setor;
    private String tipo_setor;

    public Setor(String nome_setor, String tipo_setor) {
        this.nome_setor = nome_setor;
        this.tipo_setor = tipo_setor;
    }

    public int getId() {
        return id;
    }

    public String getNome_setor() {
        return nome_setor;
    }

    public String getTipo_setor() {
        return tipo_setor;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNome_setor(String nome_setor) {
        this.nome_setor = nome_setor;
    }

    public void setTipo_setor(String tipo_setor) {
        this.tipo_setor = tipo_setor;
    }
    

}
