package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
    public static Connection conectar() {
        String conexao = "jdbc:mysql://200.195.171.124:3306/grupo05_saciIntegrador?user=grupo05&password=Uib4AV0cgH3DjAwB&useSSL=false&serverTimezone=UTC";

        try {
            // Tentar carregar o driver do MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Estabelecer a conexão
            Connection conn = DriverManager.getConnection(conexao);
            System.out.println("Conexão estabelecida com sucesso!");
            return conn;

        } catch (ClassNotFoundException e) {
            System.err.println("Driver não encontrado: " + e.getMessage());
            e.printStackTrace();
            return null; // Retorna null em caso de falha no carregamento do driver
        } catch (SQLException e) {
            System.err.println("Erro ao conectar: " + e.getMessage());
            e.printStackTrace();
            return null; // Retorna null em caso de falha na conexão
        }
    }
}

