package model;

public class Evolucao {
    
    private int id;
    private int id_paciente;
    private String descricao;

    public Evolucao(int id_paciente, String descricao) {
        this.id_paciente = id_paciente;
        this.descricao = descricao;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_paciente() {
        return id_paciente;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setId_paciente(int id_paciente) {
        this.id_paciente = id_paciente;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    

}
