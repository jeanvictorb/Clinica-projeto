
package controller;

import model.Conexao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import model.Conexao;
import model.Paciente ;

public class PacienteController {
    
    private Connection connection;

    public PacienteController() {
        connection = Conexao.conectar();
    }
    
    public void adicionarPaciente(Paciente paciente) {
        String sql = "INSERT INTO Paciente (nome, cpf, rg, Numero_sus, data_nascimento, telefone, celular, email, sexo, cep, estado, cidade, bairro, rua, numero, data_entrada) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, paciente.getNome());
            stmt.setString(2, paciente.getCpf());
            stmt.setString(3, paciente.getRg());
            stmt.setString(4, paciente.getNumero_sus());
            stmt.setString(5, paciente.getData_nascimento());
            stmt.setString(6, paciente.getTelefone());
            stmt.setString(7, paciente.getCelular());
            stmt.setString(8, paciente.getEmail());
            stmt.setString(9, paciente.getSexo());
            stmt.setString(10, paciente.getCEP());
            stmt.setString(11, paciente.getEstado());
            stmt.setString(12, paciente.getCidade());
            stmt.setString(13, paciente.getBairro());
            stmt.setString(14, paciente.getRua());
            stmt.setString(15, paciente.getNumero());
            stmt.setString(16, paciente.getData_entrada());
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null,"Operação realizada com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            System.out.println("Erro ao adicionar produto: " + e.getMessage());
        }
    }
    
     public List<Paciente> consultar() {
        List<Paciente> listaPacientes = new ArrayList<>();
        String sql = "SELECT * FROM Paciente ORDER BY id";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                ResultSet resultadoSentenca = stmt.executeQuery();

                while (resultadoSentenca.next()) {
                    Paciente paciente = new Paciente();
                    paciente.setId(resultadoSentenca.getInt("id"));
                    paciente.setNome(resultadoSentenca.getString("nome"));
                    paciente.setCpf(resultadoSentenca.getString("cpf"));
                    paciente.setRg(resultadoSentenca.getString("rg"));
                    paciente.setTelefone(resultadoSentenca.getString("telefone"));
                    paciente.setCelular(resultadoSentenca.getString("celular"));
                    paciente.setEmail(resultadoSentenca.getString("email"));

                    listaPacientes.add(paciente);
            }
            stmt.close();
            return listaPacientes;
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }
    
    public List<Paciente> consultarPorNome(String nome) {
        List<Paciente> listaPacientes = new ArrayList<>();
            String sql = "SELECT * FROM Paciente WHERE nome LIKE ? ORDER BY id";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setString(1, "%" + nome + "%");
                ResultSet resultadoSentenca = stmt.executeQuery();

                while (resultadoSentenca.next()) {
                    Paciente paciente = new Paciente();
                    paciente.setId(resultadoSentenca.getInt("id"));
                    paciente.setNome(resultadoSentenca.getString("nome"));
                    paciente.setCpf(resultadoSentenca.getString("cpf"));
                    paciente.setRg(resultadoSentenca.getString("rg"));
                    paciente.setTelefone(resultadoSentenca.getString("telefone"));
                    paciente.setCelular(resultadoSentenca.getString("celular"));
                    paciente.setEmail(resultadoSentenca.getString("email"));

                    listaPacientes.add(paciente);

            }
            stmt.close();
            return listaPacientes;
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }
    
        public List<Paciente> consultarPorCpf(String cpf) {
        List<Paciente> listaPacientes = new ArrayList<>();
            String sql = "SELECT * FROM Paciente WHERE cpf LIKE ? ORDER BY id";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setString(1, "%" + cpf + "%");
                ResultSet resultadoSentenca = stmt.executeQuery();

                while (resultadoSentenca.next()) {
                    Paciente paciente = new Paciente();
                    paciente.setId(resultadoSentenca.getInt("id"));
                    paciente.setNome(resultadoSentenca.getString("nome"));
                    paciente.setCpf(resultadoSentenca.getString("cpf"));
                    paciente.setRg(resultadoSentenca.getString("rg"));
                    paciente.setTelefone(resultadoSentenca.getString("telefone"));
                    paciente.setCelular(resultadoSentenca.getString("celular"));
                    paciente.setEmail(resultadoSentenca.getString("email"));

                    listaPacientes.add(paciente);

            }
            stmt.close();
            return listaPacientes;
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }
    
        public void excluir(String Cpf) {
        String sql = "DELETE FROM Paciente WHERE cpf = ?";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {

                stmt.setString(1, Cpf);
                stmt.execute();
                stmt.close();
            
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }
    
    
}
