package controller;

import model.Conexao;
import model.Enfermeiro;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class EnfermeiroController {

    private final Connection connection;

    public EnfermeiroController() {
        connection = Conexao.conectar();
    }

    public void adicionarEnfermeiro(Enfermeiro enfermeiro) {
        String sql = "INSERT INTO Enfermeiro (nome, cpf, rg, corem, telefone, celular, email) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, enfermeiro.getNome());
            stmt.setString(2, enfermeiro.getCpf());
            stmt.setString(3, enfermeiro.getRg());
            stmt.setString(4, enfermeiro.getCorem());
            stmt.setString(5, enfermeiro.getTelefone());
            stmt.setString(6, enfermeiro.getCelular());
            stmt.setString(7, enfermeiro.getEmail());
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Operação realizada com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao adicionar enfermeiro: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    public List<Enfermeiro> consultarTodos() {
        String sql = "SELECT * FROM Enfermeiro ORDER BY id";
        return consultar(sql, null);
    }

    public List<Enfermeiro> consultarPorNome(String nome) {
        String sql = "SELECT * FROM Enfermeiro WHERE nome LIKE ? ORDER BY id";
        return consultar(sql, "%" + nome + "%");
    }

    public List<Enfermeiro> consultarPorCpf(String cpf) {
        String sql = "SELECT * FROM Enfermeiro WHERE cpf LIKE ? ORDER BY id";
        return consultar(sql, "%" + cpf + "%");
    }

    private List<Enfermeiro> consultar(String sql, String parametro) {
        List<Enfermeiro> listaEnfermeiros = new ArrayList<>();
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            if (parametro != null) {
                stmt.setString(1, parametro);
            }
            ResultSet resultadoSentenca = stmt.executeQuery();
            while (resultadoSentenca.next()) {
                Enfermeiro enfermeiro = new Enfermeiro();
                enfermeiro.setId(resultadoSentenca.getInt("id"));
                enfermeiro.setNome(resultadoSentenca.getString("nome"));
                enfermeiro.setCpf(resultadoSentenca.getString("cpf"));
                enfermeiro.setRg(resultadoSentenca.getString("rg"));
                enfermeiro.setCorem(resultadoSentenca.getString("corem"));
                enfermeiro.setTelefone(resultadoSentenca.getString("telefone"));
                enfermeiro.setCelular(resultadoSentenca.getString("celular"));
                enfermeiro.setEmail(resultadoSentenca.getString("email"));
                listaEnfermeiros.add(enfermeiro);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao consultar enfermeiros: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
        return listaEnfermeiros;
    }
}
