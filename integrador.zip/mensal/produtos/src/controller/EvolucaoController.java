package controller;
import model.Conexao;
import model.Evolucao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class EvolucaoController {
    private Connection connection;

    public EvolucaoController() {
        connection = Conexao.conectar();
    }

    public void adicionarEvolucao(Evolucao evolucao) {
        String sql = "INSERT INTO Evolucao_Paciente (id_paciente, descricao) VALUES (?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, evolucao.getId_paciente() );
            stmt.setString(2, evolucao.getDescricao());

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null,"Operação realizada com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            System.out.println("Erro ao adicionar Setor: " + e.getMessage());
        }
    }

    public List<Evolucao> listarEvolucao() {
        List<Evolucao> evolucoes = new ArrayList<>();
        String sql = "SELECT * FROM Evolucao_Paciente";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Evolucao evolucao = new Evolucao(rs.getInt("id_paciente"), rs.getString("descricao"));
                evolucao.setId(rs.getInt("id"));
                evolucoes.add(evolucao);
            }
        } catch (SQLException e) {
            System.out.println("Erro ao listar setores: " + e.getMessage());
        }
        return evolucoes;
    }
    
        public List<Evolucao> listarEvolucaoPorPaciente(String nome) {
        List<Evolucao> evolucoes = new ArrayList<>();
        String sql = "SELECT ep.*\n" +
                    "FROM Evolucao_Paciente ep\n" +
                    "JOIN Paciente p ON ep.id_paciente = p.id\n" +
                    "WHERE p.nome = ?;";
        
        
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
    stmt.setString(1, nome);

    try (ResultSet rs = stmt.executeQuery()) {
        while (rs.next()) {
            int id = rs.getInt("id");
            int idPaciente = rs.getInt("id_paciente");
            String descricao = rs.getString("descricao");

            System.out.println("ID: " + id + ", ID do Paciente: " + idPaciente + ", Descrição: " + descricao);
        }
    }
} catch (SQLException e) {
    e.printStackTrace();
}
        return evolucoes;
    }

    public List<Evolucao> listarEvolucaoPorPacienteCPF(String cpf) {
        List<Evolucao> evolucoes = new ArrayList<>();
        String sql = "SELECT ep.*\n" +
                    "FROM Evolucao_Paciente ep\n" +
                    "JOIN Paciente p ON ep.id_paciente = p.id\n" +
                    "WHERE p.cpf = ?;";
        
        
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
    stmt.setString(1, cpf);

    try (ResultSet rs = stmt.executeQuery()) {
        while (rs.next()) {
            int id = rs.getInt("id");
            int idPaciente = rs.getInt("id_paciente");
            String descricao = rs.getString("descricao");

            System.out.println("ID: " + id + ", ID do Paciente: " + idPaciente + ", Descrição: " + descricao);
        }
    }
} catch (SQLException e) {
    e.printStackTrace();
}
        return evolucoes;
    }


}
