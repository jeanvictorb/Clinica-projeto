package controller;

import model.Conexao;
import model.Setor;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class SetorController {
    private Connection connection;

    public SetorController() {
        connection = Conexao.conectar();
    }

    public void adicionarSetor(Setor produto) {
        String sql = "INSERT INTO Setor (nome_setor, tipo_setor) VALUES (?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, produto.getNome_setor());
            stmt.setString(2, produto.getTipo_setor());
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null,"Operação realizada com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            System.out.println("Erro ao adicionar Setor: " + e.getMessage());
        }
    }

    public List<Setor> listarSetor() {
        List<Setor> setores = new ArrayList<>();
        String sql = "SELECT * FROM setor";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Setor setor = new Setor(rs.getString("nome_setor"), rs.getString("tipo_setor"));
                setor.setId(rs.getInt("id_setor"));
                setores.add(setor);
            }
        } catch (SQLException e) {
            System.out.println("Erro ao listar setores: " + e.getMessage());
        }
        return setores;
    }

    public void excluirSetor(int id) {
        String sql = "DELETE FROM Setor WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Erro ao excluir setor: " + e.getMessage());
        }
    }
}
