/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import model.Conexao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import model.Conexao;
import model.Medico ;
/**
 *
 * @author Alexa
 */
public class MedicoController {
    
    private Connection connection;

    public MedicoController() {
        connection = Conexao.conectar();
    }
    
    public void adicionarMedico(Medico medico) {
        String sql = "INSERT INTO Medico (nome, cpf, rg, crm, telefone, celular, email, especialidade) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, medico.getNome());
            stmt.setString(2, medico.getCpf());
            stmt.setString(3, medico.getRg());
            stmt.setString(4, medico.getCrm());
            stmt.setString(5, medico.getTelefone());
            stmt.setString(6, medico.getCelular());
            stmt.setString(7, medico.getEmail());
            stmt.setString(8, medico.getEspecialidade());
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null,"Operação realizada com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            System.out.println("Erro ao adicionar produto: " + e.getMessage());
        }
    }


    public List<Medico> consultar() {
        List<Medico> listaMedicos = new ArrayList<>();
        String sql = "SELECT * FROM Medico ORDER BY id";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                ResultSet resultadoSentenca = stmt.executeQuery();

                while (resultadoSentenca.next()) {
                    Medico medico = new Medico();
                    medico.setId(resultadoSentenca.getInt("id"));
                    medico.setNome(resultadoSentenca.getString("nome"));
                    medico.setCpf(resultadoSentenca.getString("cpf"));
                    medico.setCrm(resultadoSentenca.getString("crm"));
                    medico.setRg(resultadoSentenca.getString("rg"));
                    medico.setTelefone(resultadoSentenca.getString("telefone"));
                    medico.setCelular(resultadoSentenca.getString("celular"));
                    medico.setEmail(resultadoSentenca.getString("email"));
                    medico.setEspecialidade(resultadoSentenca.getString("especialidade"));

                    listaMedicos.add(medico);

            }
            stmt.close();
            return listaMedicos;
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }
    
    public List<Medico> consultarPorNome(String nome) {
        List<Medico> listaMedicos = new ArrayList<>();
            String sql = "SELECT * FROM Medico WHERE nome LIKE ? ORDER BY id";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setString(1, "%" + nome + "%");
                ResultSet resultadoSentenca = stmt.executeQuery();

                while (resultadoSentenca.next()) {
                    Medico medico = new Medico();
                    medico.setId(resultadoSentenca.getInt("id"));
                    medico.setNome(resultadoSentenca.getString("nome"));
                    medico.setCpf(resultadoSentenca.getString("cpf"));
                    medico.setCrm(resultadoSentenca.getString("crm"));
                    medico.setRg(resultadoSentenca.getString("rg"));
                    medico.setTelefone(resultadoSentenca.getString("telefone"));
                    medico.setCelular(resultadoSentenca.getString("celular"));
                    medico.setEmail(resultadoSentenca.getString("email"));
                    medico.setEspecialidade(resultadoSentenca.getString("especialidade"));

                    listaMedicos.add(medico);

            }
            stmt.close();
            return listaMedicos;
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }
    
        public List<Medico> consultarPorCrm(String crm) {
        List<Medico> listaMedicos = new ArrayList<>();
            String sql = "SELECT * FROM Medico WHERE crm LIKE ? ORDER BY id";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setString(1, "%" + crm + "%");
                ResultSet resultadoSentenca = stmt.executeQuery();

                while (resultadoSentenca.next()) {
                    Medico medico = new Medico();
                    medico.setId(resultadoSentenca.getInt("id"));
                    medico.setNome(resultadoSentenca.getString("nome"));
                    medico.setCpf(resultadoSentenca.getString("cpf"));
                    medico.setCrm(resultadoSentenca.getString("crm"));
                    medico.setRg(resultadoSentenca.getString("rg"));
                    medico.setTelefone(resultadoSentenca.getString("telefone"));
                    medico.setCelular(resultadoSentenca.getString("celular"));
                    medico.setEmail(resultadoSentenca.getString("email"));
                    medico.setEspecialidade(resultadoSentenca.getString("especialidade"));

                    listaMedicos.add(medico);

            }
            stmt.close();
            return listaMedicos;
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }
    
        public void excluir(String Crm) {
        String sql = "DELETE FROM Medico WHERE crm = ?";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {

                stmt.setString(1, Crm);
                stmt.execute();
                stmt.close();
            
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }
    
}
